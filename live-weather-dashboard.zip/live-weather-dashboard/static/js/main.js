const API_WEATHER = "/api/weather";
const API_CITIES = "/api/cities";

document.addEventListener("DOMContentLoaded", () => {
  const cityInput = document.getElementById("cityInput");
  const searchBtn = document.getElementById("searchBtn");
  const geoBtn = document.getElementById("geoBtn");
  const addFavBtn = document.getElementById("addFavBtn");
  const errBox = document.getElementById("errorBox");

  let currentCity = null;
  let tempChart = null;
  const refreshInterval = 3 * 60 * 1000; // 3 minutes

  async function fetchWeather(payload) {
    try {
      const res = await fetch(API_WEATHER, {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      return data;
    } catch (err) {
      throw err;
    }
  }

  function showError(msg) {
    errBox.textContent = msg;
    errBox.classList.remove("d-none");
    setTimeout(() => errBox.classList.add("d-none"), 5000);
  }

  function renderNow(now) {
    document.getElementById("weatherCard").classList.remove("d-none");
    document.getElementById("cityName").textContent = `${now.name}, ${now.sys.country}`;
    document.getElementById("weatherDesc").textContent = now.weather[0].description;
    document.getElementById("temp").textContent = Math.round(now.main.temp);
    document.getElementById("humidity").textContent = now.main.humidity;
    document.getElementById("wind").textContent = now.wind.speed;
    document.getElementById("icon").src = `http://openweathermap.org/img/wn/${now.weather[0].icon}@2x.png`;
  }

  function aggregateForecast(fc) {
    const days = {};
    fc.list.forEach(item => {
      const d = item.dt_txt.split(" ")[0];
      if (!days[d]) days[d] = [];
      days[d].push(item);
    });
    return Object.entries(days).slice(0, 5).map(([date, items]) => {
      const temps = items.map(i => i.main.temp);
      const avg = temps.reduce((a,b) => a+b,0)/temps.length;
      return { date, avg: Math.round(avg), icon: items[0].weather[0].icon, desc: items[0].weather[0].description };
    });
  }

  function renderForecast(fc) {
    document.getElementById("charts").classList.remove("d-none");
    const slice = fc.list.slice(0, 16);
    const labels = slice.map(i => i.dt_txt);
    const data = slice.map(i => i.main.temp);

    const ctx = document.getElementById("tempChart").getContext("2d");
    if (tempChart) tempChart.destroy();
    tempChart = new Chart(ctx, {
      type: "line",
      data: {
        labels: labels,
        datasets: [{
          label: "Temperature (°C)",
          data: data,
          fill: false,
          borderColor: "rgb(75, 192, 192)",
          tension: 0.2
        }]
      },
      options: {
        scales: {
          x: { display: true, ticks: { maxRotation: 0, autoSkip: true } },
          y: { beginAtZero: false }
        }
      }
    });

    const list = aggregateForecast(fc);
    const forecastList = document.getElementById("forecastList");
    forecastList.innerHTML = "";
    list.forEach(it => {
      const li = document.createElement("li");
      li.className = "list-group-item d-flex justify-content-between align-items-center";
      li.innerHTML = `<div><strong>${it.date}</strong><div style="font-size:.9em">${it.desc}</div></div><div>${it.avg}°C <img src="http://openweathermap.org/img/wn/${it.icon}.png" /></div>`;
      forecastList.appendChild(li);
    });
  }

  async function showCityWeather(city) {
    try {
      const data = await fetchWeather({city});
      if (data.error) {
        showError(data.error);
        return;
      }
      currentCity = city;
      renderNow(data.now);
      renderForecast(data.forecast);
    } catch (err) {
      showError(err.message || "Failed to fetch");
    }
  }

  searchBtn.addEventListener("click", () => {
    const city = cityInput.value.trim();
    if (!city) return showError("Enter a city");
    showCityWeather(city);
  });

  geoBtn.addEventListener("click", () => {
    if (!navigator.geolocation) return showError("Geolocation not supported");
    navigator.geolocation.getCurrentPosition(async (pos) => {
      const {latitude, longitude} = pos.coords;
      try {
        const data = await fetchWeather({lat: latitude, lon: longitude});
        if (data.error) return showError(data.error);
        renderNow(data.now);
        renderForecast(data.forecast);
        currentCity = data.now.name;
      } catch (e) {
        showError(e.message);
      }
    }, (err) => showError("Geolocation permission denied"));
  });

  async function loadSaved() {
    const res = await fetch(API_CITIES);
    const arr = await res.json();
    const ul = document.getElementById("savedCities");
    ul.innerHTML = "";
    arr.forEach(c => {
      const li = document.createElement("li");
      li.className = "list-group-item d-flex justify-content-between align-items-center";
      li.innerHTML = `<span>${c.name}</span>
        <div>
          <button class="btn btn-sm btn-primary btn-view" data-name="${c.name}">View</button>
          <button class="btn btn-sm btn-danger btn-remove" data-id="${c.id}">Remove</button>
        </div>`;
      ul.appendChild(li);
    });
    document.querySelectorAll(".btn-view").forEach(b => {
      b.onclick = () => showCityWeather(b.dataset.name);
    });
    document.querySelectorAll(".btn-remove").forEach(b => {
      b.onclick = async () => {
        await fetch(API_CITIES, {method:'DELETE', headers:{'Content-Type':'application/json'}, body:JSON.stringify({id: b.dataset.id})});
        loadSaved();
      };
    });
  }

  addFavBtn.addEventListener("click", async () => {
    const name = (cityInput.value || currentCity || "").trim();
    if (!name) return showError("No city to save");
    await fetch(API_CITIES, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({name})});
    loadSaved();
  });

  setInterval(() => {
    if (currentCity) showCityWeather(currentCity);
  }, refreshInterval);

  const toggleTheme = document.getElementById("toggleTheme");
  toggleTheme.addEventListener("click", () => {
    document.body.classList.toggle("dark");
    toggleTheme.textContent = document.body.classList.contains("dark") ? "Light" : "Dark";
  });

  loadSaved();
});
