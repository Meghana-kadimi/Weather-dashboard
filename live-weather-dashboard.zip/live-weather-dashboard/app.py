import os
import requests
from flask import Flask, render_template, request
from flask_sqlalchemy import SQLAlchemy
from dotenv import load_dotenv
import matplotlib
matplotlib.use('Agg')  # For server rendering
import matplotlib.pyplot as plt

load_dotenv()

app = Flask(__name__)

# Configure DB (SQLite)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///weather.db'
db = SQLAlchemy(app)

# DB model for storing searches
class SearchHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    city = db.Column(db.String(100), nullable=False)

# OpenWeather API
API_KEY = os.getenv("API_KEY")  # your OpenWeatherMap API key
BASE_URL = "http://api.openweathermap.org/data/2.5/weather"
AQI_URL = "http://api.openweathermap.org/data/2.5/air_pollution"

def get_weather(city):
    params = {"q": city, "appid": API_KEY, "units": "metric"}
    res = requests.get(BASE_URL, params=params).json()
    return res

def get_aqi(lat, lon):
    params = {"lat": lat, "lon": lon, "appid": API_KEY}
    res = requests.get(AQI_URL, params=params).json()
    return res["list"][0]["main"]["aqi"] if "list" in res else None

@app.route("/", methods=["GET", "POST"])
def index():
    weather_data = None
    aqi = None
    alert = None
    chart_url = None
    history = SearchHistory.query.order_by(SearchHistory.id.desc()).limit(5).all()

    if request.method == "POST":
        city = request.form.get("city")
        if city:
            # Save search in DB
            new_search = SearchHistory(city=city)
            db.session.add(new_search)
            db.session.commit()

            # Weather data
            data = get_weather(city)
            if data.get("cod") != 200:
                weather_data = {"error": "City not found"}
            else:
                temp = data["main"]["temp"]
                humidity = data["main"]["humidity"]
                wind = data["wind"]["speed"]
                condition = data["weather"][0]["description"]
                lat, lon = data["coord"]["lat"], data["coord"]["lon"]

                weather_data = {
                    "city": city.title(),
                    "temp": temp,
                    "humidity": humidity,
                    "wind": wind,
                    "condition": condition,
                }

                # AQI
                aqi = get_aqi(lat, lon)

                # Alerts (simple)
                if temp > 35:
                    alert = "⚠️ High Temperature! Stay Hydrated."
                elif "rain" in condition:
                    alert = "🌧️ Rain Expected! Carry an Umbrella."
                else:
                    alert = "✅ Weather looks good."

                # Chart
                plt.figure()
                plt.bar(["Temp", "Humidity", "Wind"], [temp, humidity, wind])
                plt.title(f"Weather Stats - {city}")
                chart_path = os.path.join("static", "chart.png")
                plt.savefig(chart_path)
                chart_url = "static/chart.png"

    return render_template("index.html", weather=weather_data, aqi=aqi, alert=alert, chart=chart_url, history=history)

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True)
